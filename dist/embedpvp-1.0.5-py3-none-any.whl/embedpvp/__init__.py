# An __init__.py with initialization code
print("Initializing the package")